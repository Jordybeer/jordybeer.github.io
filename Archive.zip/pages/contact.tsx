import ContactFormulier from "../components/form";

const Contact = () => {
  return <ContactFormulier />;
};

export default Contact;
