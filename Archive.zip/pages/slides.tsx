import Layout from "../components/layout";
import NextJsCarousel from "../components/mobcar";
const Contact = () => {
  return <NextJsCarousel />;
};

export default Contact;
