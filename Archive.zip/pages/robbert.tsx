import Layout from "../components/layout";
import RobbertComponent from "../components/robbertcomponent";

const Robbert: React.FC = () => {
  return <RobbertComponent />;
};

export default Robbert;
