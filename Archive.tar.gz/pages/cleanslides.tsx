import { Cleanslides } from "../components/cleanslides";

const Clean = () => {
  return <Cleanslides />;
};

export default Clean;
